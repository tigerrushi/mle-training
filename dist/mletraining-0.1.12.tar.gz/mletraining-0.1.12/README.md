# mle-training
MLE Training for Assignments 

### Steps to run the Python code
```sh
git clone https://github.com/tigerrushi/mle-training.git
cd mle-training
conda env create -f env.yml
cd mle_code_snippet
pip install sklearn
python nonstandardcode.py
```
