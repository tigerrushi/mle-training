# setup.py placed at root directory

from setuptools import setup, find_packages


setup(
    name="mletraining",
    version="0.1.12",
    author="Rushikesh Naik",
    description="MLE training Project. Fun Project!",
    long_description="This Project will help to find the regression values with help of differnt parameters",
    packages=["src/data_ingest", "src/model_scoring", "src/model_training", "src/logs"],
    install_requires=[
        "pandas",
        "six",
        "scikit-learn",
        "numpy",
        "pickle-mixin",
        "mlflow",
        "matplotlib",
    ]
    # python_requires='>=3.7, <4',
    # install_requires=['pandas'],
    # extras_require={
    #     'test': ['pytest', 'coverage'],
    # },
    # package_data={
    #     'sample': ['example_data.csv'],
    # },
    # entry_points={
    #     'runners': [
    #         'sample=sample:main',
    #     ]
    # }
)
